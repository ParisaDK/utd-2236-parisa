package myds;

public interface MyStack<E> {
    void push(E x);
    E pop();     // return null if empty
    E peek();    // return null if empty
    boolean isEmpty();
    int size();
}
